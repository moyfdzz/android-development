<<<<<<< HEAD
### 11-04-2021 :
      * Prueba de configuraciones (visual, estructura)
      * Pantalla de inicio
      * Bosquejo de seccion de quiz
      * Codigo de generacion de respuestas aleatorias para quizzes
=======
# Proyecto de curso de Python de la clase Aplicaciones Moviles en Android
gerardo
>>>>>>> 48818e3 (join)
