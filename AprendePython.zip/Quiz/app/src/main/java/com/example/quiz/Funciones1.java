package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Funciones1 extends AppCompatActivity {
    Colors py = new Colors();
    Integer dato1 = 1;
    Integer dato2 = 1;

    public Integer getDato1(){
        return dato1;
    }
    public Integer getDato2() { return dato2; }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }

    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funciones1);

        showCode("1", "1");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Funciones");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }

    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight, code)));
    }

    String result = "";
    public String getRes() {
        return result;
    }
    public void setRes(String newVal){
        result = newVal;
    }

    public void showCode( String int1, String int2){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){

            dato1 = Integer.valueOf(int1);
            dato2 = Integer.valueOf(int2);

            code[0][0] = py.def + " " + py.addFunc + py.lpar + py.n1yellow + ", " + py.n2yellow + py.rpar + ":" + py.br;
            code[0][1] = py.indent + py.retu + " " + "num1 + num2" + py.br;

            code[0][2] = py.br;

            code[0][3] = py.def + py.main + py.lpar + py.rpar + ":" + py.br;
            code[0][4] = py.indent + "dato1 = " + py.ent + py.lpar + py.input + py.lpar2 + py.rpar2 + py.rpar + py.br;
            code[0][5] = py.indent + "dato2 = " + py.ent + py.lpar + py.input + py.lpar2 + py.rpar2 + py.rpar + py.br;

            code[0][6] = py.indent + "res = " + py.addFunc + py.lpar + "dato1, dato2" + py.rpar + py.br;
            code[0][7] = py.indent + py.print + py.lpar + "res" + py.rpar + py.br;


            render();

            setRes(String.valueOf((dato1 + dato2)));

            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String[][] getErrors(){
        String[][] errors = new String[2][30];

        errors[0][0] = "";
        errors[0][1] = "dato1 = " + dato1 + "\n";
        errors[0][2] = "dato2 = " + dato2 + "\n";
        errors[0][3] = "res = add(" + dato1 + "," + dato2 + ")" + "\n";
        errors[0][4] = "def add(" + dato1 + "," + dato2 + ")" + "\n";
        errors[0][5] = "return " + dato1 + " + " + dato2 + "\n";
        errors[0][6] = "print(" + result + ")" + "\n";

        errors[1][0] = "3";
        errors[1][1] = "4";
        errors[1][2] = "5";
        errors[1][3] = "6";
        errors[1][4] = "0";
        errors[1][5] = "1";
        errors[1][6] = "7";

        return errors;
    }

    public void goto_back(View v){
        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones1_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones1_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}