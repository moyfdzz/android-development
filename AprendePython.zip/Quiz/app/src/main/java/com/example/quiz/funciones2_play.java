package com.example.quiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class funciones2_play extends Fragment {

    public funciones2_play() {
        // Required empty public constructor
    }

    public static funciones2_play newInstance(String param1, String param2) {
        funciones2_play fragment = new funciones2_play();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_funciones2_play, container, false);

        Button button = (Button) view.findViewById(R.id.updateButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText input1 = getView().findViewById(R.id.dato1In);

                try{
                    String dato1 = input1.getText().toString();

                    ((Funciones2) getActivity()).showCode(dato1);
                }catch(Exception e){
                    ((Funciones2) getActivity()).showCode("nombre");
                }
            }
        });

        return view;
    }
}