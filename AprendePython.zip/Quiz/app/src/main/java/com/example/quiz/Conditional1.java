package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Conditional1 extends AppCompatActivity {

    Colors py = new Colors();


    Integer dato1 = 1;
    Integer dato2 = 1;
    String op = "+";
    public Integer getDato1(){
        return dato1;
    }
    public Integer getDato2(){
        return dato2;
    }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }

    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conditional1);

        showCode("1", "1","+");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Condicional");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }


    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight,code)));
    }

    String result = "";
    public String getRes() {
        return result;
    }
    public void setRes(String newVal){
        result = newVal;
    }

    public void showCode( String int1, String int2, String str1){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){

            dato1 = Integer.valueOf(int1);
            dato2 = Integer.valueOf(int2);
            op = str1;

            code[0][0] = py.def + py.main+py.lpar+py.rpar+":" + py.br;
            code[0][1] = py.indent + "dato1 "+ py.eq + " " + py.int_input + py.br;
            code[0][2] = py.indent + "dato2 "+ py.eq + " " + py.int_input + py.br;
            code[0][3] = py.indent + "op " + py.eq + " " + py.input + py.lpar + py.rpar + py.br;

            code[0][4] = py.indent + py.IF + py.lpar + "op " + py.eq + py.eq + py.addColor(" '+'",py.yellow) + py.rpar+":" + py.br;
            code[0][5] = py.indent + py.indent + py.print + py.lpar + "dato1 " + py.plus + " dato2" + py.rpar + py.br;


            code[0][6] = py.indent + py.ELIF + py.lpar + "op " + py.eq + py.eq + py.addColor(" '*'",py.yellow) +py.rpar + " :" + py.br;
            code[0][7] = py.indent + py.indent + py.print + py.lpar + "dato1 " + py.mult + " dato2" + py.rpar + py.br;

            code[0][8] = py.indent + py.ELSE + " :" + py.br;
            code[0][9] = py.indent + py.indent + py.print + py.lpar + py.addColor("'ERROR'",py.yellow) + py.rpar + py.br;

            render();
            if(op.contains("+")){
                setRes(String.valueOf((dato1 + dato2)));
            }else if(op.contains("*")){
                setRes(String.valueOf((dato1 * dato2)));
            }else{
                setRes("ERROR");
            }
            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String[][] getErrors(){
        String[][] errors = new String[2][30];

        errors[0][0] = "";
        errors[0][1] = "dato1 = " + dato1 + "\n";
        errors[0][2] = "dato2 = " + dato2 + "\n";
        errors[0][3] = "op = "+ op +"\n";
        errors[0][4] = "if(" + op + " == '+'):\n";

        errors[1][0] = "0";
        errors[1][1] = "1";
        errors[1][2] = "2";
        errors[1][3] = "3";
        errors[1][4] = "4";

        if(op.contains("+")){
            errors[0][5] = "print(" + dato1 + " + " + dato2 + ")\n";
            errors[0][6] = "print(" + getRes() + ")\n";

            errors[1][5] = "5";
            errors[1][6] = "5";
        }else if(op.contains("*")){
            errors[0][5] = "if(" + op + " == '*'):\n";
            errors[0][6] = "print(" + dato1 + " * " + dato2 + ")\n";
            errors[0][7] = "print(" + getRes() + ")\n";


            errors[1][5] = "6";
            errors[1][6] = "7";
            errors[1][7] = "7";
        }else{
            errors[0][5] = "if(" + op + " == '*'):\n";
            errors[0][6] = "";
            errors[0][7] = "print('ERROR')\n";

            errors[1][5] = "6";
            errors[1][6] = "8";
            errors[1][7] = "9";
        }

        return errors;
    }


    public void goto_back(View v){
        FragmentManager fm = getSupportFragmentManager();
        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new conditional1_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new conditional1_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}