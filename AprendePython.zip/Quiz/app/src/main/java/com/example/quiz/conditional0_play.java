package com.example.quiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class conditional0_play extends Fragment {


    public conditional0_play() {
    }


    public static conditional0_play newInstance(String param1, String param2) {
        conditional0_play fragment = new conditional0_play();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_conditional0_play, container, false);

        Button button = (Button) view.findViewById(R.id.updateButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText input1 = getView().findViewById(R.id.dato1In);
                EditText input2 = getView().findViewById(R.id.dato2In);

                try{
                    String dato1 = input1.getText().toString();
                    String dato2 = input2.getText().toString();
                    ((Conditional0) getActivity()).showCode(dato1, dato2);
                }catch(Exception e){
                    ((Conditional0) getActivity()).showCode("1", "1");
                }
            }
        });

        return view;
    }
}