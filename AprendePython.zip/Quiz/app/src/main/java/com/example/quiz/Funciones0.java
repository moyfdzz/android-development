package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Funciones0 extends AppCompatActivity {

    Colors py = new Colors();
    Integer dato1 = 1;

    public Integer getDato1(){
        return dato1;
    }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }

    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funciones0);

        showCode("1");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Funciones");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }


    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight, code)));
    }

    String result = "";
    public String getRes() {
        return result;
    }
    public void setRes(String newVal){
        result = newVal;
    }

    public void showCode( String int1){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){

            dato1 = Integer.valueOf(int1);

            String funcName = py.addColor(" esPar",py.green);
            code[0][0] = py.addColor("# esta función regresa verdadero si num es par", py.twilight) + py.br;
            code[0][1] = py.def + funcName + py.lpar + py.addColor("num",py.orange) + py.rpar + ":" + py.br;
            code[0][2] = py.indent + py.RETURN + " num " + py.mod + " 2 "+ py.eq + py.eq + py.addColor(" 0", py.purple) + py.br;
            code[0][3] = py.br;

            code[0][4] = py.def + py.main + py.lpar + py.rpar + ":" + py.br;
            code[0][5] = py.indent + "dato1 " + py.eq + " " + py.int_input + py.br;

            code[0][6] = py.indent + py.IF + py.lpar + funcName + py.lpar2 + "dato1" + py.rpar2 + " " + py.rpar + ":" + py.br;
            code[0][7] = py.indent + py.indent + py.print + py.lpar + py.addColor("'es par'", py.yellow) + py.rpar + py.br;

            code[0][8] = py.indent + py.ELSE + " :" + py.br;
            code[0][9] = py.indent + py.indent + py.print + py.lpar + py.addColor("'es impar'",py.yellow) + py.rpar + py.br;

            render();

            if(dato1 % 2 == 0){
                setRes("es par");
            }else{
                setRes("es impar");
            }
            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String[][] getErrors(){
        String[][] errors = new String[2][30];

        errors[0][0] = "";
        errors[0][1] = "dato1 = " + dato1 + "\n";
        errors[0][2] = "if( esPar(" + dato1 +")):\n";
        errors[0][3] = "def isEven(" + dato1 + "):\n";
        errors[0][4] = "return " + dato1 + "%2 == 0\n";
        errors[0][5] = "";


        errors[1][0] = "4";
        errors[1][1] = "5";
        errors[1][2] = "6";
        errors[1][3] = "1";
        errors[1][4] = "2";
        errors[1][5] = "6";

        if(dato1 % 2 == 0){
            errors[0][6] = "print('es par')\n";

            errors[1][6] = "7";
        }else{
            errors[0][6] = "";
            errors[0][7] = "print('es impar')\n";

            errors[1][6] = "8";
            errors[1][7] = "9";
         }

        return errors;
    }

    public void goto_back(View v){
        FragmentManager fm = getSupportFragmentManager();
        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }

        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones0_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones0_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}