package com.example.quiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class operator0_debugger extends Fragment {

    public operator0_debugger() {
        // Required empty public constructor
    }


    public static operator0_debugger newInstance() {
        operator0_debugger fragment = new operator0_debugger();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    Integer dato1 = 0;
    Integer dato2 = 0;
    Integer LOC = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_operator0_debugger, container, false);

        dato1 = ((Operadores0) getActivity()).getDato1();
        dato2 = ((Operadores0) getActivity()).getDato2();
        LOC = ((Operadores0) getActivity()).getLOC();


        Button nextBtn = (Button) v.findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView console = (TextView)getView().findViewById(R.id.bugConsole);
                Integer highlight = ((Operadores0) getActivity()).getHighlight();


                if(highlight == LOC){
                    highlight = -1;
                }
                ((Operadores0) getActivity()).setHighlight(highlight + 1);
                String errors = ((Operadores0) getActivity()).getErrors();
                console.setText(errors);
                ((Operadores0) getActivity()).render();
            }
        });

        return v;
    }

}