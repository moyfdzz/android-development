package com.example.quiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link funciones1_play#newInstance} factory method to
 * create an instance of this fragment.
 */
public class funciones1_play extends Fragment {

    public funciones1_play() {
        // Required empty public constructor
    }

    public static funciones1_play newInstance(String param1, String param2) {
        funciones1_play fragment = new funciones1_play();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_funciones1_play, container, false);

        Button button = (Button) view.findViewById(R.id.updateButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText input1 = getView().findViewById(R.id.dato1In);
                EditText input2 = getView().findViewById(R.id.dato2In);

                try{
                    String dato1 = input1.getText().toString();
                    String dato2 = input2.getText().toString();

                    ((Funciones1) getActivity()).showCode(dato1, dato2);
                }catch(Exception e){
                    ((Funciones1) getActivity()).showCode("1", "1");
                }
            }
        });

        return view;
    }
}