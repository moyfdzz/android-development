package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Conditional0 extends AppCompatActivity {

    Colors py = new Colors();

    Integer dato1 = 1;
    Integer dato2 = 1;
    public Integer getDato1(){
        return dato1;
    }
    public Integer getDato2(){
        return dato2;
    }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }

    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conditional0);

        showCode("1", "1");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Condicional");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }

    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight, code)));
    }

    String result = "";
    public String getRes() {
        return result;
    }
    public void setRes(String newVal){
        result = newVal;
    }

    public void showCode( String int1, String int2){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){

            dato1 = Integer.valueOf(int1);
            dato2 = Integer.valueOf(int2);

            String zero = py.addColor(" 0 ",py.purple);
            String num25 = py.addColor(" 25 ",py.purple);

            code[0][0] = py.def + py.main+py.lpar+py.rpar+":" + py.br;
            code[0][1] = py.indent + "dato1 "+ py.eq + " " + py.int_input + py.br;
            code[0][2] = py.indent + "dato2 "+ py.eq + " " + py.int_input + py.br;
            code[0][3] = py.indent + py.IF + py.lpar + "dato1 >= " + zero + py.and + " dato2 < " + num25 + py.rpar+":" + py.br;
            code[0][4] = py.indent + py.indent + py.print +py.lpar+py.T+py.rpar+py.br;
            code[0][5] = py.indent + py.ELSE +" :"+py.br;
            code[0][6] = py.indent + py.indent + py.print +py.lpar+py.F+py.rpar+py.br;

            render();
            if(dato1 >= 0 && dato2 < 25){
                setRes("True");
            }else{
                setRes("False");
            }
            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String[][] getErrors(){
        String[][] errors = new String[2][30];

        errors[0][0] = "";
        errors[0][1] = "dato1 = " + dato1 + "\n";
        errors[0][2] = "dato2 = " + dato2 + "\n";
        errors[0][3] = "if(" + dato1 + " >= 0 and " + dato2 + " < 25):\n";

        errors[1][0] = "0";
        errors[1][1] = "1";
        errors[1][2] = "2";
        errors[1][3] = "3";

        if(dato1 >= 0 && dato2 < 25){
            errors[0][4] = "if(True):\n";
            errors[0][5] = "print(True)\n";

            errors[1][4] = "3";
            errors[1][5] = "4";
        }else{
            errors[0][4] = "if(False)\n";
            errors[0][5] = "";
            errors[0][6] = "print(False)\n";

            errors[1][4] = "3";
            errors[1][5] = "5";
            errors[1][6] = "6";
        }

        return errors;
    }


    public void goto_back(View v){

        FragmentManager fm = getSupportFragmentManager();
        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new conditional0_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new conditional0_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}