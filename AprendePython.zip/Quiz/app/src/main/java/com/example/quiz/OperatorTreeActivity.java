package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class OperatorTreeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operator_tree);
    }

    public void goto_0(View v){
        Intent i = new Intent(this, Operadores0.class);
        startActivity(i);
    }

    public void goto_1(View v){
        Intent i = new Intent(this, Operadores1.class);
        startActivity(i);
    }

    public void goto_back(View v){
        onBackPressed();
    }
}