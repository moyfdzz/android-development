package com.example.quiz;

public class next {
}
