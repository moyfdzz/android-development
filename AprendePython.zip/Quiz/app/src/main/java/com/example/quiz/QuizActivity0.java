package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import java.util.HashMap;

public class QuizActivity0 extends AppCompatActivity {

    Button ansBtn1,ansBtn2,ansBtn3,ansBtn4;
    Colors cl = new Colors();
    int var1,var2;
    String[][] code = new String[2][20];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz0);
        ansBtn1 = findViewById(R.id.answer1);
        ansBtn2 = findViewById(R.id.answer2);
        ansBtn3 = findViewById(R.id.answer3);
        ansBtn4 = findViewById(R.id.answer4);

        Object[] ansBool = quiz();
        showCode();
        ansBtn1.setOnClickListener(v -> onChoice(0,ansBool));

        ansBtn2.setOnClickListener(v -> onChoice(1,ansBool));

        ansBtn3.setOnClickListener(v -> onChoice(2,ansBool));

        ansBtn4.setOnClickListener(v -> onChoice(3,ansBool));
    }

    public void render(){
        TextView codeView = findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(cl.getDisplay(cl.highlight,code)));
    }



    public  void onChoice(int i,Object[] ansBool){
        if (ansBool[i].toString().equals("false")) {
            Toast.makeText(QuizActivity0.this, "Incorrecto :(",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(QuizActivity0.this, "Correcto, felicidades!!",Toast.LENGTH_SHORT).show();
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
    }

    @SuppressLint("SetTextI18n")
    public Object[] quiz(){

        var1 = (int)Math.round(Math.random() * 10);
        var2 = (int)Math.round(Math.random() * 10 );
        int res = (var2*var2) + var1 ;

        HashMap<Integer, Boolean> answerMap = new HashMap<>();

        answerMap.put(res, true);

        int tempFalse = res;
        int falseAnswerIterator;
        for(falseAnswerIterator = 0; falseAnswerIterator < 3 ; falseAnswerIterator++){
            while(answerMap.containsKey(tempFalse)){
                tempFalse = (int)((float)res * (float)Math.random() / (float)Math.random());
            }
            answerMap.put(tempFalse,false);
        }

        Object[] answerKeys = answerMap.keySet().toArray();
        Object[] answerValues = answerMap.values().toArray();


        ansBtn1.setText(answerKeys[0].toString());
        ansBtn2.setText(answerKeys[1].toString());
        ansBtn3.setText(answerKeys[2].toString());
        ansBtn4.setText(answerKeys[3].toString());

        return answerValues;
    }


    public void showCode(){
        TextView codeView = findViewById(R.id.mainCode);

        String var1S  =  cl.addColor(Integer.toString(var1),cl.purple);
        String var2S  =  cl.addColor(Integer.toString(var2),cl.purple);

            code[0][0] = cl.def + cl.main + cl.lpar + cl.rpar+":" + cl.br;
            code[0][1] = cl.indent + "barco "+ cl.eq + " " + var1S + cl.br;
            code[0][2] = cl.indent + "coche "+ cl.eq + " " + var2S + cl.br;
            code[0][3] = cl.indent + "coche " + cl.multEq + " coche " + cl.br;
            code[0][4] = cl.indent + cl.print + cl.lpar + " " + "barco "  + " " + cl.plus + " " +  " coche" + cl.rpar + cl.br;

            render();
    }

    public void goto_back(View v){
        onBackPressed();
    }

}