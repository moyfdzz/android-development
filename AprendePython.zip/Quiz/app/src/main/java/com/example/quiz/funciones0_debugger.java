package com.example.quiz;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class funciones0_debugger extends Fragment {

    public funciones0_debugger() {
        // Required empty public constructor
    }

    public static funciones0_debugger newInstance(String param1, String param2) {
        funciones0_debugger fragment = new funciones0_debugger();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    Integer dato1 = 0;
    Integer LOC = 0;

    Integer highlight = -1;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view = inflater.inflate(R.layout.fragment_funciones0_debugger, container, false);

        highlight = -1;
        dato1 = ((Funciones0) getActivity()).getDato1();
        LOC = ((Funciones0) getActivity()).getLOC();

        String[][] errors = ((Funciones0) getActivity()).getErrors();

        Button nextBtn = (Button) view.findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView console = (TextView)getView().findViewById(R.id.bugConsole);

                dato1 = ((Funciones0) getActivity()).getDato1();
                String terminalText = "";


                highlight += 1;

                if(highlight == getLength(errors[0])){
                    highlight = -1;
                    ((Funciones0) getActivity()).setHighlight(-1);
                    console.setText("");
                    ((Funciones0) getActivity()).render();
                }

                if(highlight >= 0){
                    for(int i = 0; i <= highlight;i++ ){
                        terminalText += errors[0][i];
                    }
                    try{
                        ((Funciones0) getActivity()).setHighlight(Integer.valueOf(errors[1][highlight]));
                        console.setText(terminalText);
                        ((Funciones0) getActivity()).render();
                    }catch(Exception e){
                        highlight=-1;
                    }

                }
            }
        });

        return view;
    }

    public Integer getLength(String[] arr){

        for(int i = 0; i<arr.length;i++){
            if(arr[i] == null){
                return i;
            }
        }
        return arr.length;
    }
}