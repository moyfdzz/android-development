package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Operadores1 extends AppCompatActivity {

    Colors py = new Colors();

    Integer dato1 = 1;
    Integer dato2 = 1;
    public Integer getDato1(){
        return dato1;
    }
    public Integer getDato2(){
        return dato2;
    }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }


    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operadores1);

        showCode("1", "1");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Operadores");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }

    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight,code)));
    }

    Integer result = 0;
    public Integer getRes() {
        return result;
    }
    public void setRes(Integer newVal){
        result = newVal;
    }

    public void showCode( String int1, String int2){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){
            if(int1 == ""){
                int1 = "1";
            }
            if(int2 == ""){
                int2 = "1";
            }
            dato1 = Integer.valueOf(int1);
            dato2 = Integer.valueOf(int2);
            if(dato1 == null){
                dato1 = 1;
            }
            if(dato2 == null){
                dato2 = 1;
            }

            code[0][0] = py.def + py.main+py.lpar+py.rpar+":" + py.br;
            code[0][1] = py.indent + "dato1 "+ py.eq + " " + py.int_input + py.br;
            code[0][2] = py.indent + "dato2 "+ py.eq + " " + py.int_input + py.br;
            code[0][3] = py.indent + py.print + py.lpar + py.addColor("6 ",py.purple) + py.mult + py.addColor(" 4 ", py.purple) + py.div + "dato1 ";
            code[0][3] += py.plus + " dato2 " + py.div + py.addColor(" 8 ",py.purple)  + py.rpar + py.br;

            render();
            setRes(6 * 4 / dato1 + dato2 / 8);
            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String getErrors(){
        String[] errors = new String[30];
        errors[0] = "";
        errors[1] = "dato1 = " + dato1 + "\n";
        errors[2] = "dato2 = " + dato2 + "\n";
        errors[3] = "print(6 * 4/"+dato1+" + "+dato2+"/8)\n";
        errors[4] = "print(" + String.valueOf(getRes()) + ")";

        String resp = "";
        for(int i = 0; i<=getHighlight();i++){
            resp += errors[i];
        }
        return resp;
    }

    public void goto_back(View v){
        FragmentManager fm = getSupportFragmentManager();
        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
            fm.popBackStack();
        }
        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new operator1_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new operator1_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}