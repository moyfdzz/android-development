package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TreeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tree);
    }

    public void goto_debugger(View v){
        Intent i = new Intent(this, debugger.class);
        startActivity(i);
    }

    public void goto_func(View v){
        Intent i = new Intent(this, FunctionTreeActivity.class);
        startActivity(i);
    }

    public void goto_op(View v){
        Intent i = new Intent(this, OperatorTreeActivity.class);
        startActivity(i);
    }

    public void goto_cond(View v){
        Intent i = new Intent(this, ConditionalTreeActivity.class);
        startActivity(i);
    }

    public void goto_back(View v){
        onBackPressed();
    }

}