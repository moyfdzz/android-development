package com.example.quiz;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link operator1_debugger#newInstance} factory method to
 * create an instance of this fragment.
 *
 */
public class operator1_debugger extends Fragment {

    public static operator1_debugger newInstance(String param1, String param2) {
        operator1_debugger fragment = new operator1_debugger();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    public operator1_debugger() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }
    Integer dato1 = 0;
    Integer dato2 = 0;
    Integer LOC = 0;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_operator1_debugger, container, false);

        dato1 = ((Operadores1) getActivity()).getDato1();
        dato2 = ((Operadores1) getActivity()).getDato2();
        LOC = ((Operadores1) getActivity()).getLOC();


        Button nextBtn = (Button) view.findViewById(R.id.nextBtn);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView console = (TextView)getView().findViewById(R.id.bugConsole);
                Integer highlight = ((Operadores1) getActivity()).getHighlight();


                if(highlight == LOC){
                    highlight = -1;
                }
                ((Operadores1) getActivity()).setHighlight(highlight + 1);
                String errors = ((Operadores1) getActivity()).getErrors();
                console.setText(errors);
                ((Operadores1) getActivity()).render();
            }
        });

        return view;
    }
}