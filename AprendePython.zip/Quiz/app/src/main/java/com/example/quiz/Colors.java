package com.example.quiz;
public class Colors {


        String dusk     = "#6272A4";
        String twilight = "#44475A";
        String pink     = "#FF79C6";
        String green    = "#50FA7B";
        String yellow   = "#F1FA8C";
        String purple   = "#BD93F9";
        String red      = "#FF5555";
        String orange   = "#FFB86C";
        String cyan     = "#8BE9FD";

        String def   =  addColor("def ",pink);
        String lpar  =  addColor("(", yellow);
        String rpar  =  addColor(")", yellow);
        String lpar2 =  addColor("(", red);
        String rpar2 =  addColor(")", red);
        String main  =  addColor("main",green);
        String ent   = addColor("int",cyan);
        String input = addColor("input",cyan);
        String print = addColor("print",cyan);
        String n1yellow = addColor("num1", yellow);
        String n2yellow = addColor("num2", yellow);
        String retu  =  addColor("return",pink);
        String addFunc  =  addColor("add",green);
        String greetFunc  =  addColor("greet",green);
        String nyellow = addColor("name", yellow);
        String int_input = ent + lpar + input + lpar2 + rpar2 + rpar;

        String plus   =  addColor("+",pink);
        String minus  =  addColor("-",pink);
        String div    =  addColor("/",pink);
        String mult   =  addColor("*",pink);
        String multEq =  addColor("*=",pink);
        String eq     =  addColor("=",pink);
        String and    = addColor("and",pink);
        String IF     = addColor("if",pink);
        String ELSE   = addColor("else",pink);
        String ELIF   = addColor("elif",pink);
        String RETURN   = addColor("return",pink);
        String mod   = addColor("%",pink);
        String T      = addColor("'True'",orange);
        String F      = addColor("'False'",orange);

        String br = "<br/>";
        String indent = "\t\t\t";
        Integer highlight = -1;

    public String defName(String s){
        String res = "<font color="+green+">"+s+"</font>";
        return res;
    }
    public String argName(String s){
        String res = "<font color="+orange+">"+s+"</font>";
        return res;
    }

    public String num(String s){
        String res = "<font color="+purple+">"+s+"</font>";
        return res;
    }

    public String addColor(String keyword, String color){
        return "<font color="+color+">"+keyword+"</font>";
    }

    public String getDisplay(int highlight, String[][] code) {
        String text = "";
        for (Integer i = 0; i < code[0].length; i++) {
            if (code[0][i] == null) {
                return text;
            }

            if (i == highlight) {
                String selected = "<span style=\"background-color:" + dusk + "\">" + code[0][i] + "</span>";
                text += selected;
            } else {
                text += code[0][i];
            }
        }
        return text;

    }
}
