package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import java.util.HashMap;

public class QuizActivity1 extends AppCompatActivity {

    Button ansBtn1,ansBtn2,ansBtn3,ansBtn4;
    float var1,var2;
    Colors cl = new Colors();
    String[][] code = new String[2][20];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz1);

        ansBtn1 = findViewById(R.id.answer1);
        ansBtn2 = findViewById(R.id.answer2);
        ansBtn3 = findViewById(R.id.answer3);
        ansBtn4 = findViewById(R.id.answer4);

        Object[] ansBool = quiz();
        showCode();
        ansBtn1.setOnClickListener(v -> onChoice(0,ansBool));

        ansBtn2.setOnClickListener(v -> onChoice(1,ansBool));

        ansBtn3.setOnClickListener(v -> onChoice(2,ansBool));

        ansBtn4.setOnClickListener(v -> onChoice(3,ansBool));
    }

    public void render(){
        TextView codeView = findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(cl.getDisplay(cl.highlight,code)));
    }

    public  void onChoice(int i,Object[] ansBool){
        if (ansBool[i].toString().equals("false")) {
            Toast.makeText(QuizActivity1.this, "Incorrecto :(",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(QuizActivity1.this, "Correcto, felicidades!!",Toast.LENGTH_SHORT).show();
            Intent intent = getIntent();
            finish();
            startActivity(intent);
        }
    }
    @SuppressLint("SetTextI18n")
    public Object[] quiz(){

        var1 = (float)(Math.random() * 10);
        var2 = (float)(Math.random() * 10);

        float res = (var2 * var1) - var1 ;

        HashMap<Float, Boolean> answerMap = new HashMap<>();

        answerMap.put(res, true);

        float tempFalse = res;
        int falseAnswerIterator;
        for(falseAnswerIterator = 0; falseAnswerIterator < 3 ; falseAnswerIterator++){
            while(answerMap.containsKey(tempFalse)){
                tempFalse = (float)res * (float)Math.random() / (float)Math.random();
            }
            answerMap.put(tempFalse,false);
        }

        Object[] answerKeys = answerMap.keySet().toArray();
        Object[] answerValues = answerMap.values().toArray();


        ansBtn1.setText(answerKeys[0].toString());
        ansBtn2.setText(answerKeys[1].toString());
        ansBtn3.setText(answerKeys[2].toString());
        ansBtn4.setText(answerKeys[3].toString());

        return answerValues;
    }

    public void showCode( ){
        String var1S  =  cl.addColor(Float.toString(var1),cl.purple);
        String var2S  =  cl.addColor(Float.toString(var2),cl.purple);

            code[0][0] = cl.def + cl.main + cl.lpar + cl.rpar + ":" + cl.br;
            code[0][1] = cl.indent + "manzana "+ cl.eq + " " + var1S + cl.br;
            code[0][2] = cl.indent + "platano "+ cl.eq  + " naranja  " + cl.eq +" " + var2S + cl.br;
            code[0][3] = cl.indent + "pera " + cl.eq + " platano " + cl.mult + " manzana " + cl.br;
            code[0][4] = cl.indent + cl.print + cl.lpar + " " + " pera "  + " " + cl.minus + " " +  " manzana" + cl.rpar + cl.br;

            render();
    }

    public void goto_back(View v){
        onBackPressed();
    }
}