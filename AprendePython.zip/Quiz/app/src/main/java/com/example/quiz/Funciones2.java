package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

public class Funciones2 extends AppCompatActivity {
    Colors py = new Colors();
    String dato1 = "nombre";

    public String getDato1(){
        return dato1;
    }

    String[][] code = new String[2][20];
    Integer highlight = -1;
    public Integer getHighlight(){
        return highlight;
    }
    public void setHighlight(Integer newVal){
        highlight = newVal;
    }

    public Integer getLOC(){
        int i;
        for(i=0;i<code[0].length;i++){
            if(code[0][i] == null){
                return i;
            }
        }
        return i;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funciones2);

        showCode("nombre");
        TextView title = (TextView) findViewById(R.id.title);
        title.setText("Funciones");

        TextView codeResult = (TextView) findViewById(R.id.codeRes);
        codeResult.setText("RESPUESTA");
    }

    public void render(){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        codeView.setText(Html.fromHtml(py.getDisplay(highlight, code)));
    }

    String result = "";
    public String getRes() {
        return result;
    }
    public void setRes(String newVal){
        result = newVal;
    }

    public void showCode( String nombre){
        TextView codeView = (TextView) findViewById(R.id.mainCode);
        TextView codeResult = (TextView) findViewById(R.id.codeRes);

        if(codeView != null){

            dato1 = String.valueOf(nombre);

            code[0][0] = py.def + " " + py.greetFunc + py.lpar + py.nyellow + py.rpar + ":" + py.br;
            code[0][1] = py.indent + py.print + py.lpar + "\"Hello \" + name" + py.rpar + py.br;

            code[0][2] = py.br;
            code[0][3] = py.def + py.main + py.lpar + py.rpar + ":" + py.br;
            code[0][4] = py.indent + "name = " + py.input + py.lpar + py.rpar + py.br;
            code[0][5] = py.indent + py.greetFunc + py.lpar + "name" + py.rpar + py.br;


            render();

            setRes(String.valueOf(("Hello " + dato1)));

            codeResult.setText(">> " + String.valueOf(getRes()));
        }
    }

    public String[][] getErrors(){
        String[][] errors = new String[2][30];

        errors[0][0] = "";
        errors[0][1] = "name = " + dato1 + "\n";
        errors[0][2] = "greet(" + dato1 + ")" + "\n";
        errors[0][3] = "def greet(" + dato1 + ")" + "\n";
        errors[0][4] = "print" + "(\"Hello \"+ " + " \n " + dato1 + ")" + "\n";


        errors[1][0] = "3";
        errors[1][1] = "4";
        errors[1][2] = "5";
        errors[1][3] = "0";
        errors[1][4] = "1";

        return errors;
    }

    public void goto_back(View v){
        onBackPressed();
    }

    public void goto_debugger_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones2_debugger(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }

    public void goto_play_fragment(View v){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .replace(R.id.fragment, new funciones2_play(), null)
                .setReorderingAllowed(true)
                .addToBackStack(null)
                .commit();
    }
}