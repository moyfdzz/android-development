package com.example.tarea_4_a01197049;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Initial initialFragment = Initial.newInstance();

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        Initial fragment = (Initial) getSupportFragmentManager().findFragmentById(R.id.contenedor_fragment);

        if (fragment == null) {
            fragmentTransaction.add(R.id.contenedor_fragment, initialFragment).commit();
        }
    }
}